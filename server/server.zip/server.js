const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
const cors = require('cors');
const { connectDB } = require('./config/db');

// Load env vars
dotenv.config();

// Connect to database
connectDB();

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// 1. Static: Serve uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 2. Base Route (Test)
app.get('/', (req, res) => {
    res.send('API is running...');
});

// Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/stories', require('./routes/storyRoutes'));
app.use('/api/upload', require('./routes/uploadRoutes'));
app.use('/api/subscribers', require('./routes/subscriberRoutes'));
app.use('/api/ai', require('./routes/aiRoutes'));
app.use('/api/categories', require('./routes/categoryRoutes'));

const PORT = process.env.PORT || 5000;
// --- توجيه الفرونت إند (يجب أن يكون في النهاية) ---

// 3. Static: Serve Frontend (CSS/JS files)
app.use(express.static(path.join(__dirname, 'public')));

// 4. API 404 Handler (Safe Regex)
// يجب أن يأتي قبل توجيه React! أي رابط يبدأ بـ /api ولم يجده يظهر 404
app.all(/\/api\/.*/, (req, res) => {
    res.status(404).json({ message: 'API route not found' });
});

// 5. Catch-All Handler (SPA Routing)
// أي رابط آخر (مثل /library, /admin) يرسل إليه ملف index.html
app.use((req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});