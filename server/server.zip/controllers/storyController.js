const Story = require('../models/Story');
const fs = require('fs');
const path = require('path');

// Helper to delete file
const deleteFile = (fileUrl) => {
    if (!fileUrl) return;
    try {
        const filename = fileUrl.split('/uploads/').pop();
        if (!filename) return;

        const filePath = path.join(__dirname, '../uploads', filename);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            console.log(`Deleted file: ${filePath}`);
        }
    } catch (err) {
        console.error(`Failed to delete file: ${fileUrl}`, err);
    }
};

// @desc    Get all stories
// @route   GET /api/stories
// @access  Public
const getStories = async (req, res) => {
    try {
        const stories = await Story.findAll();
        res.status(200).json(stories);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Get story by ID
// @route   GET /api/stories/:id
// @access  Public
const getStoryById = async (req, res) => {
    try {
        const story = await Story.findByPk(req.params.id);
        if (!story) {
            return res.status(404).json({ message: 'Story not found' });
        }
        res.status(200).json(story);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Create a story
// @route   POST /api/stories
// @access  Private (Admin)
const createStory = async (req, res) => {
    try {
        const story = await Story.create(req.body);
        res.status(201).json(story);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Update a story
// @route   PUT /api/stories/:id
// @access  Private (Admin)
const updateStory = async (req, res) => {
    try {
        const story = await Story.findByPk(req.params.id);

        if (!story) {
            return res.status(404).json({ message: 'Story not found' });
        }

        // Check if files are being updated and delete old ones
        if (req.body.coverImage && req.body.coverImage !== story.coverImage) {
            deleteFile(story.coverImage);
        }
        if (req.body.pdfUrl && req.body.pdfUrl !== story.pdfUrl) {
            deleteFile(story.pdfUrl);
        }

        await story.update(req.body);
        res.status(200).json(story);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Delete a story
// @route   DELETE /api/stories/:id
// @access  Private (Admin)
const deleteStory = async (req, res) => {
    try {
        const story = await Story.findByPk(req.params.id);

        if (!story) {
            return res.status(404).json({ message: 'Story not found' });
        }

        // Delete associated files
        deleteFile(story.coverImage);
        deleteFile(story.pdfUrl);

        await story.destroy();
        res.status(200).json({ id: req.params.id });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Increment views
// @route   PATCH /api/stories/:id/view
// @access  Public
const incrementViews = async (req, res) => {
    try {
        const story = await Story.findByPk(req.params.id);
        if (!story) return res.status(404).json({ message: 'Story not found' });

        await story.increment('views');
        res.status(200).json({ message: 'Views incremented' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Increment downloads
// @route   PATCH /api/stories/:id/download
// @access  Public
const incrementDownloads = async (req, res) => {
    try {
        const story = await Story.findByPk(req.params.id);
        if (!story) return res.status(404).json({ message: 'Story not found' });

        await story.increment('downloads');
        res.status(200).json({ message: 'Downloads incremented' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

module.exports = {
    getStories,
    getStoryById,
    createStory,
    updateStory,
    deleteStory,
    incrementViews,
    incrementDownloads
};
