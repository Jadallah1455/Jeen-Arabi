const { Sequelize } = require('sequelize');
const mysql = require('mysql2/promise');
require('dotenv').config();

const dbName = process.env.DB_NAME || 'jeen_arabi';
const dbUser = process.env.DB_USER || 'root';
const dbPass = process.env.DB_PASS || '';
const dbHost = process.env.DB_HOST || '127.0.0.1';

const sequelize = new Sequelize(
  dbName,
  dbUser,
  dbPass,
  {
    host: dbHost,
    dialect: 'mysql',
    logging: false,
  }
);

const connectDB = async () => {
  try {
    // Step 1: Create DB if not exists
    const connection = await mysql.createConnection({ host: dbHost, user: dbUser, password: dbPass });
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\`;`);
    await connection.end();

    // Step 2: Authenticate with Sequelize
    await sequelize.authenticate();
    console.log('MySQL Connected via Sequelize');

    // Step 3: Sync models
    await sequelize.sync({ alter: true });
    console.log('Database Synced');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
};

module.exports = { sequelize, connectDB };
