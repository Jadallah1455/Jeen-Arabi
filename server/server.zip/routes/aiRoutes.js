const express = require('express');
const router = express.Router();
const { generateStory } = require('../controllers/aiController');

router.post('/generate-story', generateStory);

module.exports = router;
