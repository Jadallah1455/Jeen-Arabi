const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { protect, admin } = require('../middleware/authMiddleware');
const router = express.Router();

const cloudinary = require('cloudinary').v2;
const { CloudinaryStorage } = require('multer-storage-cloudinary');

// Ensure uploads directory exists for local storage
const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure Cloudinary
cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET
});

// Determine storage engine
// Force Local Disk Storage
console.log('Using Local Disk Storage');
storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        // Sanitize filename to remove special characters
        const originalName = file.originalname.replace(/[^a-zA-Z0-9.]/g, '_');
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + originalName);
    }
});

const upload = multer({ storage: storage });

router.post('/', protect, admin, upload.single('file'), (req, res) => {
    if (req.file) {
        let fileUrl;
        // Local storage URL
        fileUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;

        // Delete old file if provided
        if (req.body.oldFileUrl) {
            try {
                const oldFilename = req.body.oldFileUrl.split('/uploads/').pop();
                if (oldFilename) {
                    const oldFilePath = path.join(uploadDir, oldFilename);
                    if (fs.existsSync(oldFilePath)) {
                        fs.unlinkSync(oldFilePath);
                        console.log('Deleted old file:', oldFilename);
                    }
                }
            } catch (err) {
                console.error('Error deleting old file:', err);
            }
        }

        res.json({ url: fileUrl });
    } else {
        res.status(400).json({ message: 'File upload failed' });
    }
});

router.delete('/:filename', protect, admin, async (req, res) => {
    try {
        const { filename } = req.params;

        // Check if we are using Cloudinary (if env vars exist)
        const filePath = path.join(uploadDir, filename);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            res.json({ message: 'File deleted' });
        } else {
            res.status(404).json({ message: 'File not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
