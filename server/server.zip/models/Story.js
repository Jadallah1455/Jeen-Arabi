const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Story = sequelize.define('Story', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    title: {
        type: DataTypes.JSON, // Stores { en: "...", ar: "..." }
        allowNull: false,
        defaultValue: {}
    },
    description: {
        type: DataTypes.JSON, // Stores { en: "...", ar: "..." }
        allowNull: false,
        defaultValue: {}
    },
    availableLanguages: {
        type: DataTypes.JSON, // Stores ["en", "ar"]
        defaultValue: []
    },
    coverImage: {
        type: DataTypes.STRING,
        allowNull: false
    },
    pdfUrl: {
        type: DataTypes.STRING,
        allowNull: true
    },
    ageGroup: {
        type: DataTypes.STRING,
        defaultValue: '3-5'
    },
    categoryLabel: {
        type: DataTypes.STRING,
        defaultValue: 'English'
    },
    tags: {
        type: DataTypes.JSON, // Stores ["tag1", "tag2"]
        allowNull: false,
        defaultValue: []
    },
    categories: {
        type: DataTypes.JSON, // Stores ["catId1", "catId2"]
        allowNull: false,
        defaultValue: []
    },
    views: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    downloads: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    }
});

module.exports = Story;
