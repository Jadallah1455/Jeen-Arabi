const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Category = sequelize.define('Category', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    name: {
        type: DataTypes.JSON, // Stores { en: "...", ar: "..." }
        allowNull: false,
        defaultValue: {}
    },
    description: {
        type: DataTypes.JSON, // Stores { en: "...", ar: "..." }
        allowNull: true,
        defaultValue: {}
    }
});

module.exports = Category;
