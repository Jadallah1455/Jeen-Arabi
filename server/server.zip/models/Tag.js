const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Tag = sequelize.define('Tag', {
    name: {
        type: DataTypes.JSON, // { en: "Nature", ar: "طبيعة" }
        allowNull: false
    },
    slug: {
        type: DataTypes.STRING,
        unique: true
    },
    count: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    }
});

module.exports = Tag;
